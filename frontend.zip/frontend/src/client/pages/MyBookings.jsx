import React from 'react';
import { Box, Heading, Text } from '@chakra-ui/react';

const MyBookings = () => {
  return (
    <Box p={5}>
      <Heading mb={6}>My Bookings</Heading>
      <Text>Booking history and management interface will be implemented here.</Text>
    </Box>
  );
};

export default MyBookings; 